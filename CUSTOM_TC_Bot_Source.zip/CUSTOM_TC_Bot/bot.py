import os
import io
import sqlite3
import logging
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler,
    ContextTypes, filters
)

BOT_NAME = "CUSTOM TC"
SLOGAN = "CUSTOMTC"
SERVER = "VIETNAM (VN)"
DB_PATH = os.getenv("DB_PATH", "custom_tc.sqlite3")

SLOTS = [
    ("1", "13:00–15:00"),
    ("2", "15:00–17:00"),
    ("3", "17:00–19:00"),
    ("4", "20:00–21:30"),
    ("5", "21:40–23:00"),
    ("6", "23:30–01:00"),
    ("7", "01:00–03:00"),
    ("8", "10:00–12:00"),
]

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("custom-tc")


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS registrations (
                chat_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                username TEXT,
                display_name TEXT NOT NULL,
                ff_uid TEXT NOT NULL,
                slot_id TEXT NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY (chat_id, user_id)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_reg_chat_slot ON registrations(chat_id, slot_id)")


def slot_label(slot_id):
    return next((label for key, label in SLOTS if key == slot_id), "Chưa rõ")


def main_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📝 Đăng ký thi đấu", callback_data="begin_register")],
        [InlineKeyboardButton("⏰ Khung giờ", callback_data="show_schedule"),
         InlineKeyboardButton("🏆 Bảng đăng ký", callback_data="show_rank")],
        [InlineKeyboardButton("👤 Hồ sơ", callback_data="show_profile"),
         InlineKeyboardButton("🖼 Tạo ảnh bảng", callback_data="show_board")],
    ])


def slot_keyboard():
    rows = []
    for i in range(0, len(SLOTS), 2):
        pair = SLOTS[i:i+2]
        rows.append([
            InlineKeyboardButton(f"{key} · {label}", callback_data=f"slot:{key}")
            for key, label in pair
        ])
    rows.append([InlineKeyboardButton("❌ Hủy", callback_data="cancel_register")])
    return InlineKeyboardMarkup(rows)


def get_rows(chat_id):
    with db() as conn:
        return conn.execute(
            "SELECT * FROM registrations WHERE chat_id=? ORDER BY slot_id, display_name",
            (chat_id,)
        ).fetchall()


def get_user(chat_id, user_id):
    with db() as conn:
        return conn.execute(
            "SELECT * FROM registrations WHERE chat_id=? AND user_id=?",
            (chat_id, user_id)
        ).fetchone()


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("awaiting_uid", None)
    msg = (
        f"🔥 *{BOT_NAME}* · {SLOGAN}\n"
        f"🇻🇳 Server: *{SERVER}*\n\n"
        "Chào mừng bạn đến với bot đăng ký giải đấu Free Fire.\n"
        "Chọn chức năng bên dưới hoặc dùng /help."
    )
    await update.effective_message.reply_text(msg, parse_mode="Markdown", reply_markup=main_menu())


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "📖 *HƯỚNG DẪN CUSTOM TC*\n\n"
        "/start – Mở menu\n"
        "/register – Đăng ký UID và khung giờ\n"
        "/uid – Nhập/cập nhật UID\n"
        "/schedule – Xem 8 khung giờ\n"
        "/rank – Xem danh sách đăng ký trong chat hiện tại\n"
        "/profile – Xem đăng ký của bạn\n"
        "/board – Tạo ảnh bảng đăng ký\n"
        "/cancel – Hủy thao tác đang nhập\n\n"
        "Mỗi tài khoản có một đăng ký trong từng chat. Đăng ký trong nhóm và chat riêng được lưu riêng."
    )
    await update.effective_message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu())


async def begin_register(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["awaiting_uid"] = True
    await update.effective_message.reply_text(
        "🎮 Gửi UID Free Fire của bạn (chỉ gồm chữ số, thường 5–15 số).\n"
        "Không gửi mật khẩu hoặc mã đăng nhập."
    )


async def register_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await begin_register(update, context)


async def uid_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await begin_register(update, context)


async def receive_uid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.user_data.get("awaiting_uid"):
        return
    uid = (update.effective_message.text or "").strip()
    if not uid.isdigit() or not (5 <= len(uid) <= 15):
        await update.effective_message.reply_text("UID chưa hợp lệ. Hãy gửi UID chỉ gồm 5–15 chữ số.")
        return
    context.user_data["pending_uid"] = uid
    context.user_data["awaiting_uid"] = False
    await update.effective_message.reply_text(
        f"Đã nhận UID: `{uid}`\n\nChọn khung giờ thi đấu:",
        parse_mode="Markdown",
        reply_markup=slot_keyboard(),
    )


async def schedule_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lines = ["⏰ *KHUNG GIỜ CUSTOM TC*"]
    lines.extend([f"{key}. {label}" for key, label in SLOTS])
    await update.effective_message.reply_text("\n".join(lines), parse_mode="Markdown")


async def show_rank_message(message, chat_id):
    rows = get_rows(chat_id)
    if not rows:
        await message.reply_text("Chưa có người đăng ký trong cuộc trò chuyện này.")
        return
    grouped = {key: [] for key, _ in SLOTS}
    for row in rows:
        grouped[row["slot_id"]].append(row)
    lines = ["🏆 *CUSTOM TC – DANH SÁCH ĐĂNG KÝ*", f"🇻🇳 Server: {SERVER}", ""]
    for key, label in SLOTS:
        entries = grouped[key]
        lines.append(f"*Khung {key}: {label}* ({len(entries)} người)")
        for idx, row in enumerate(entries, 1):
            uname = f" (@{row['username']})" if row["username"] else ""
            lines.append(f"{idx}. {row['display_name']}{uname} · UID `{row['ff_uid']}`")
        lines.append("")
    await message.reply_text("\n".join(lines), parse_mode="Markdown")


async def rank_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_rank_message(update.effective_message, update.effective_chat.id)


async def profile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    row = get_user(update.effective_chat.id, user.id)
    if not row:
        await update.effective_message.reply_text("Bạn chưa đăng ký trong chat này. Gõ /register để bắt đầu.")
        return
    await update.effective_message.reply_text(
        f"👤 *HỒ SƠ CUSTOM TC*\nTên: {row['display_name']}\nUID: `{row['ff_uid']}`\n"
        f"Khung giờ: {row['slot_id']} · {slot_label(row['slot_id'])}\nServer: {SERVER}",
        parse_mode="Markdown"
    )


def load_font(size):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            try:
                return ImageFont.truetype(path, size=size)
            except Exception:
                pass
    return ImageFont.load_default()


def make_board(chat_id):
    rows = get_rows(chat_id)
    width = 1100
    line_h = 46
    height = max(360, 230 + max(1, len(rows)) * line_h + len(SLOTS) * 22)
    img = Image.new("RGB", (width, height), (13, 17, 28))
    draw = ImageDraw.Draw(img)
    title_font = load_font(46)
    sub_font = load_font(25)
    head_font = load_font(27)
    body_font = load_font(23)
    draw.rounded_rectangle((25, 25, width-25, height-25), radius=28, outline=(238, 62, 67), width=5)
    draw.text((60, 50), "CUSTOM TC", font=title_font, fill=(255, 255, 255))
    draw.text((62, 112), "CUSTOMTC  |  FREE FIRE TOURNAMENT  |  VIETNAM (VN)", font=sub_font, fill=(255, 190, 80))
    y = 180
    grouped = {key: [] for key, _ in SLOTS}
    for row in rows:
        grouped[row["slot_id"]].append(row)
    if not rows:
        draw.text((60, y), "Chua co nguoi dang ky", font=head_font, fill=(220, 225, 235))
    for key, label in SLOTS:
        entries = grouped[key]
        draw.text((60, y), f"KHUNG {key}  |  {label}  |  {len(entries)} nguoi", font=head_font, fill=(255, 190, 80))
        y += 38
        for idx, row in enumerate(entries, 1):
            name = row["display_name"]
            uid = row["ff_uid"]
            line = f"{idx}. {name}  |  UID: {uid}"
            draw.text((78, y), line[:85], font=body_font, fill=(235, 239, 246))
            y += line_h
        if not entries:
            draw.text((78, y), "Chua co dang ky", font=body_font, fill=(145, 155, 175))
            y += line_h
        y += 14
    output = io.BytesIO()
    output.name = "CUSTOM_TC_board.png"
    img.save(output, format="PNG")
    output.seek(0)
    return output


async def board_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    photo = make_board(update.effective_chat.id)
    await update.effective_message.reply_photo(photo=photo, caption="🏆 CUSTOM TC · Bảng đăng ký | Server Việt Nam")


async def cancel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("awaiting_uid", None)
    context.user_data.pop("pending_uid", None)
    await update.effective_message.reply_text("Đã hủy thao tác.")


async def callbacks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    chat_id = query.message.chat_id
    user = query.from_user

    if data == "begin_register":
        context.user_data["awaiting_uid"] = True
        await query.message.reply_text("🎮 Gửi UID Free Fire của bạn (chỉ gồm 5–15 chữ số).")
    elif data == "show_schedule":
        await schedule_cmd(update, context)
    elif data == "show_rank":
        await show_rank_message(query.message, chat_id)
    elif data == "show_profile":
        row = get_user(chat_id, user.id)
        if not row:
            await query.message.reply_text("Bạn chưa đăng ký trong chat này. Gõ /register để bắt đầu.")
        else:
            await query.message.reply_text(
                f"👤 {row['display_name']} · UID {row['ff_uid']} · Khung {row['slot_id']} ({slot_label(row['slot_id'])})"
            )
    elif data == "show_board":
        await query.message.reply_photo(photo=make_board(chat_id), caption="🏆 CUSTOM TC · Bảng đăng ký")
    elif data == "cancel_register":
        context.user_data.pop("pending_uid", None)
        context.user_data.pop("awaiting_uid", None)
        await query.message.reply_text("Đã hủy đăng ký.")
    elif data.startswith("slot:"):
        uid = context.user_data.get("pending_uid")
        if not uid:
            await query.message.reply_text("Phiên đăng ký đã hết. Gõ /register để làm lại.")
            return
        slot_id = data.split(":", 1)[1]
        if slot_id not in dict(SLOTS):
            await query.message.reply_text("Khung giờ không hợp lệ. Vui lòng thử lại bằng /register.")
            return
        display_name = user.full_name or user.first_name or "Người chơi"
        username = user.username
        with db() as conn:
            conn.execute("""
                INSERT INTO registrations(chat_id,user_id,username,display_name,ff_uid,slot_id,created_at)
                VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(chat_id,user_id) DO UPDATE SET
                    username=excluded.username,
                    display_name=excluded.display_name,
                    ff_uid=excluded.ff_uid,
                    slot_id=excluded.slot_id,
                    created_at=excluded.created_at
            """, (chat_id, user.id, username, display_name, uid, slot_id, datetime.now(timezone.utc).isoformat()))
        context.user_data.pop("pending_uid", None)
        await query.message.reply_text(
            f"✅ Đăng ký thành công!\nTên: {display_name}\nUID: {uid}\nKhung: {slot_id} · {slot_label(slot_id)}\nServer: {SERVER}",
            reply_markup=main_menu()
        )


async def post_init(application: Application):
    commands = [
        BotCommand("start", "Khoi dong bot"),
        BotCommand("register", "Dang ky thi dau"),
        BotCommand("uid", "Nhap UID Free Fire"),
        BotCommand("schedule", "Xem khung gio"),
        BotCommand("rank", "Danh sach dang ky"),
        BotCommand("profile", "Ho so nguoi choi"),
        BotCommand("board", "Tao anh bang dang ky"),
        BotCommand("cancel", "Huy thao tac"),
        BotCommand("help", "Huong dan su dung"),
    ]
    await application.bot.set_my_commands(commands)


def main():
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("Thieu BOT_TOKEN. Hay tao file .env tu .env.example va dien token.")
    init_db()
    app = Application.builder().token(token).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler(["register"], register_cmd))
    app.add_handler(CommandHandler("uid", uid_cmd))
    app.add_handler(CommandHandler("schedule", schedule_cmd))
    app.add_handler(CommandHandler("rank", rank_cmd))
    app.add_handler(CommandHandler("profile", profile_cmd))
    app.add_handler(CommandHandler("board", board_cmd))
    app.add_handler(CommandHandler("cancel", cancel_cmd))
    app.add_handler(CallbackQueryHandler(callbacks))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, receive_uid))
    log.info("CUSTOM TC is starting...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
